This is a Pytorch implementation of our RG-Explainer. 

You can use docker mapa17/torch_geometric to run all the scripts directly. 

If you use conda, please install:
python 3.7
pytorch 1.8.0
torch-geometric
networkx
numpy 
scikit-learn 
scipy 
pandas

