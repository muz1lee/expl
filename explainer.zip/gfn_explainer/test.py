import numpy as np
import time
from matplotlib import pyplot as plt
# tl = []
# d = [50*i for i in range(100)]
# for item in d:
#     print('{} nodes'.format(item))
#     a1 = np.array([i for i in range(item)]).reshape(item,1)
#     a2 = np.array([i for i in range(item)]).reshape(item,1)
#     t1= time.time()
#     a3 = a1*a2
#     t2= time.time()
#     time_d = t2-t1
#     tl.append(time_d)
#
# fg = plt.figure(figsize=(10,6))
# plt.plot(tl)
# plt.show()
#
def action(trajectory, index, tran_vec,Q_matrix,A_matrix):

    trajectory[index] = 1
    Q_matrix_new, tran_vec_new = cal_new_Q_matrix(tran_vec, Q_matrix, index, A_matrix,trajectory)
    print('Q_matrix_new\n', np.array(Q_matrix_new ==1).astype(int))
    return trajectory,Q_matrix_new,tran_vec_new


def update_new_Q_index(Q_index,A_matrix,index,trajectory):
    index_vec = A_matrix[index].astype(int) * trajectory
    if sum(index_vec)> 2:
        delete_matrix = [index_vec]*A_matrix.shape[0]

        # new_matrix = Q_index - delete_matrix
        # print('new_matrix\n',new_matrix)
        new_Q = Q_index - Q_index * delete_matrix
        print('new_matrix\n',new_Q)
        # print('new_matrix_2\n', new_matrix_2)
        # new_Q = np.array(new_matrix == 1).astype(int)
    else:
        new_Q = Q_index

    return new_Q
# def cal_new_Q_matrix(tran_vec,Q_matrix,index,A_matrix,trajectory):
#
#
#     tran_vec_new = (tran_vec.astype(int) |  A_matrix[index].astype(int) )
#     print('tran_vec', tran_vec)
#     print('tran_vec_new', tran_vec_new)
#     if list(tran_vec_new) == list(tran_vec):
#         Q_matrix = update_new_Q_index(Q_matrix,A_matrix,index,trajectory)
#     else:
#         Q_index = ( tran_vec_new - tran_vec  )
#         Q_matrix[index] = Q_index
#
#
#     # Q_matrix = Q_matrix - np.diag(np.ones(Q_matrix.shape[0]))
#
#     if len(np.where(Q_matrix[index]==1)[0])!=0:
#         for item in np.where(Q_matrix[index]==1)[0]:
#             print('{} is the cut vertex of {}'.format(index+1,item+1))
#     return Q_matrix,tran_vec_new
def cal_new_Q_matrix(tran_vec,Q_matrix,index,A_matrix,trajectory):


    tran_vec_new = (tran_vec.astype(int) |  A_matrix[index].astype(int) )

    print('tran_vec', tran_vec)
    print('tran_vec_new', tran_vec_new)
    Q_matrix_old = Q_matrix.copy()
    Q_index = (tran_vec_new - tran_vec)

    # if list(tran_vec_new)!= list(tran_vec):
    #     Q_matrix[index] = Q_index
    #     Q_matrix = (Q_matrix.T[index].reshape(4, 1) * Q_index).astype(int) | Q_matrix.astype(int)
    # print('Q_matrix_1\n',Q_matrix)
    # print('Q_matrix.T[index]',Q_matrix.T[index])
    # print('Q_matrix.T[index]',Q_matrix.T[index].reshape(4,1))
    # print(' np.dot(Q_matrix.T[index], Q_index)', Q_matrix.T[index].reshape(4,1) * Q_index)
    # Q_matrix =(Q_matrix.T[index].reshape(4,1) * Q_index).astype(int) | Q_matrix.astype(int)
    # print('test\n', Q_matrix)
    index_vec = A_matrix[index].astype(int) * trajectory
    d = A_matrix.shape[0]
    if sum(index_vec) > 2:

        A_sharp = np.array([index_vec] * d)  #A_sharp
        print('Q_matrix\n',Q_matrix)
        father = Q_matrix.T * A_sharp

        children = Q_matrix * A_sharp

        check_father = np.sum(father,axis=1)
        check_children = np.sum(children, axis=1)
        # print('check_father\n', check_father)
        # print('check_children\n', check_children)
        for i in range(d):
            if check_father[i]!=0:
                Q_matrix[i] = Q_matrix[i] - children[i]
        # 连接了父节点


        diag_matrix = np.diag(np.ones(d))
        self_node = children.copy()
        self_node[0][0]=1
        # print('self_node\n',self_node)
        check_self= np.sum(self_node, axis=1)
        # print('check_self',check_self)
        for i in range(d):
            if check_self[i] == d : # 连接了所有子节点， 最上面的那个父节点是可以删的
                Q_matrix[i] = 0

        Q_matrix[:,index] = 0
        # print('看看\n',Q_matrix)


        # print('trajectory\n',trajectory)
        # print('index_vec\n',index_vec)
        # print('A_sharp\n',A_sharp)
        # print('Q_matrix_old\n',Q_matrix_old)
        # delete_matrix = np.array([Q_matrix] * A_matrix.shape[0])
        # father = np.dot(Q_matrix.T,index_vec)
        # print('连接了父节点\n',father) # 连接了父节点
        # test_1 = (Q_matrix_old * index_vec)
        # kl = []
        # for i in range(4):
        #     if list(Q_matrix_old[i] ) == list(test_1[i]) and sum(list(test_1[i]) )!=0 :
        #         kl.append(1)
        #     else:
        #         kl.append(0)
        # kl  = np.array(kl)
        # print('连接了子节点\n', test_1) # 连接了子节点
        # test_2 = [np.sum(test_1,axis=1)>=3][0].astype(int)
        # print('连接了子节点\n', kl)
        # print('连接情况\n',(Q_matrix_old * A_sharp) *  np.dot(Q_matrix_old.T,index_vec))
        #
        # print('乘\n', father*kl)
        # item = father*kl
        # for i in item:
        #     if i==1:
        #         Q_matrix[i]=0
        # # mul = ( np.dot(father.reshape(4,1) , kl.reshape(1,4)) >0).astype(int)
        # # Q_matrix = Q_matrix -  mul
        #
        # # for i in range(Q_matrix.shape[0]):
        # #     if test_2[i] == 1:
        # #         Q_matrix[i]= 0
    else:
        Q_matrix = Q_matrix

    if list(tran_vec_new)!= list(tran_vec):
        Q_matrix[index] = Q_index
        Q_matrix = (Q_matrix.T[index].reshape(d, 1) * Q_index).astype(int) | Q_matrix.astype(int)
    # index_vec = A_matrix[index].astype(int) * trajectory
    # if sum(index_vec) != 2:
    #     delete_matrix = [index_vec] * A_matrix.shape[0]
    #
    #     # new_matrix = Q_index - delete_matrix
    #     # print('new_matrix\n',new_matrix)
    #     new_Q = Q_index - Q_index * delete_matrix

    # if list(tran_vec_new) == list(tran_vec):
    #     Q_matrix = update_new_Q_index(Q_matrix,A_matrix,index,trajectory)
    # else:
    #     Q_index = ( tran_vec_new - tran_vec  )
    #     Q_matrix[index] = Q_index


    # Q_matrix = Q_matrix - np.diag(np.ones(Q_matrix.shape[0]))

    return Q_matrix,tran_vec_new

def test_Q_update(A_matrix,index,trajectory,Q_matrix):
    d = A_matrix.shape[0]
    adjacency_of_add_node = A_matrix[index].astype(int)
    delete_self_trajectory = trajectory.copy()
    delete_self_trajectory[index] = 0
    edges_conneced_of_add_node = adjacency_of_add_node * delete_self_trajectory

    A_sharp = np.array([edges_conneced_of_add_node] * d)  # A_sharp 实际在子图里的连接

    father_matrix = Q_matrix * A_sharp
    non_father_matrix = (1 - father_matrix) * edges_conneced_of_add_node
    # 连接了non-direct-father
    check_edge = non_father_matrix * A_sharp.T
    sum_check = np.array([np.sum(check_edge, axis=1) >= 2]).astype(int)

    Q_matrix = Q_matrix * (1 - sum_check)

    new_check_next = np.where(sum_check[0]>0)[0]

    return Q_matrix,new_check_next

def cal_new_Q_matrix(tran_vec,Q_matrix,index_1,A_matrix,trajectory):


    Q_matrix_old = Q_matrix.copy()
    # adjacency_of_add_node=  A_matrix[index_1].astype(int)
    # edges_conneced_of_add_node  = adjacency_of_add_node * trajectory
    # degree = sum(edges_conneced_of_add_node)
    d = A_matrix.shape[0]
    check_next = [index_1]
    check_before =[]
    while len(check_next)!=0:
        for index in check_next:
            adjacency_of_add_node = A_matrix[index].astype(int)
            edges_conneced_of_add_node = adjacency_of_add_node * trajectory
            degree = sum(edges_conneced_of_add_node)

            if degree > 2:
                Q_matrix,check_next_new=test_Q_update(A_matrix,index,trajectory,Q_matrix)

                Q_matrix[:,index] = 0
                check_next += [item for item in check_next_new]

                check_before += [check_next[0]]
                check_next = check_next[1:]
                check_next = [item for item in check_next if item not in check_before ]
            else:
                check_next=check_next[1:]



        # A_sharp = np.array([edges_conneced_of_add_node] * d)  #A_sharp 实际在子图里的连接
        # father_matrix = Q_matrix * A_sharp
        # non_father_matrix = (1-father_matrix) * edges_conneced_of_add_node
        # check_edge = non_father_matrix* A_sharp.T
        # sum_check = np.array([np.sum(check_edge,axis=1)>=2]).astype(int)
        #
        # Q_matrix = Q_matrix * (1-sum_check)

        # non_father = 1 - Q_matrix.T * A_sharp
    #     edges_conneced_of_add_node
    #     father = Q_matrix.T * A_sharp
    #
    #     children = Q_matrix * A_sharp
    #
    #     check_father = np.sum(father,axis=1)
    #     check_children = np.sum(children, axis=1)
    #     # print('check_father\n', check_father)
    #     # print('check_children\n', check_children)
    #     for i in range(d):
    #         if check_father[i]!=0:
    #             Q_matrix[i] = Q_matrix[i] - children[i]
    #
    #     diag_matrix = np.diag(np.ones(d))
    #     self_node = children.copy()
    #     self_node[0][0]=1
    #     # print('self_node\n',self_node)
    #     check_self= np.sum(self_node, axis=1)
    #     # print('check_self',check_self)
    #     for i in range(d):
    #         if check_self[i] == d : # 连接了所有子节点， 最上面的那个父节点是可以删的
    #             Q_matrix[i] = 0
    #
    #     Q_matrix[:,index] = 0
    #
    # else:
    #     Q_matrix = Q_matrix

    tran_vec_new = (tran_vec.astype(int) | A_matrix[index].astype(int))

    print('tran_vec', tran_vec)
    print('tran_vec_new', tran_vec_new)

    Q_index = (tran_vec_new - tran_vec)
    if list(tran_vec_new)!= list(tran_vec):
        Q_matrix[index] = Q_index
        Q_matrix = (Q_matrix.T[index].reshape(d, 1) * Q_index).astype(int) | Q_matrix.astype(int)

    return Q_matrix,tran_vec_new
def main():

    A_matrix = [
        [1,1,0,0,0,0],
        [1,1,1,0,1,0],
        [0,1,1,1,0,0],
        [0,0,1,1,0,1],
        [0,1,0,0,1,1],
        [0,0,0,1,1,1]]
                # [1,1,0,0,0],
                # [1,1,1,0,1],
                # [0,1,1,1,0],
                # [0,0,1,1,1],
                # [0,1,0,1,1]
    # [1, 1, 0, 0],
    # [1, 1, 1, 1],
    # [0, 1, 1, 1],
    # [0, 1, 1, 1]

        # [1, 0, 0, 0, 1],
        # [0, 1, 1, 0, 1],
        # [0, 1, 1, 1, 0],
        # [0, 0, 1, 1, 1],
        # [1, 1, 0, 1, 1]]

        # [1, 1, 0, 1, 0],
        # [1, 1, 0, 1, 0],
        # [0, 0, 1, 0, 1],
        # [1, 1, 0, 1, 1],
        # [0, 0, 1, 1, 1]]

    A_matrix = np.array(A_matrix)

    degree = np.array([np.sum(A_matrix,axis=1)-1 ==1]).astype(int)
    d = A_matrix.shape[0]

    Q_matrix = np.array(np.zeros(d*d).reshape(d, d))


    trajectory = np.array([0]*d)
    tran_vec = np.array([0]*d)
    index_list=[1,2,3,4,5]

    for i in index_list:
        index = i
        print('Adding node {} into subgraph'.format(index+1))
        trajectory,Q_matrix,tran_vec = action(trajectory, index, tran_vec,Q_matrix,A_matrix)
        print('-----------------------------------')
    print('current subgraph is {}'.format(trajectory))
    delete_index = 1
    unconnected = trajectory * Q_matrix[delete_index]
    trajectory[delete_index] =  0

    if len(np.where(unconnected==1)[0])>0 :
        print('can not delete the node {}'.format(delete_index+1))
        for item in np.where(Q_matrix[delete_index] == 1)[0]:
            print('node {} will be unconnected'.format(item+1))
    else:
        print('could delete the node {}'.format(delete_index+1))
        print('after deleting the subgraph is {}'.format(trajectory))



if __name__ == '__main__':

    main()