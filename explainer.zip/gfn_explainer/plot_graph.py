import argparse
import datetime
import hashlib
import json
import pathlib
import time
import pandas as pd
import torch
from torch import optim
import networkx as nx
from components import *
from utils import *
import matplotlib.pyplot as plt
from datasets import dataset_loaders, ground_truth_loaders
from models import model_selector
from evaluation.AUCEvaluation import AUCEvaluation
import torch_geometric as ptgeom
import matplotlib




# ---------- Theorem visualization


# def draw(self, edge_index, node, labelnodes, pre):
# G = nx.Graph(node_size=90, font_size=80)
# colormap = []
#
# for i, j in edge_index:
#     G.add_edge(i, j)
# for i in G.nodes():
#     if i in cut_vertex_:
#         colormap.append('#FFCCCC')  # 割点
#     else:
#         colormap.append('#99CC99')  # 非割点
#
#
#
# plt.figure(figsize=(4, 3), dpi=400)  # 设置画布的大小
# nx.draw_networkx(G, node_color=colormap, with_labels=False)
# plt.show()
# plt.savefig("graphs/" + pre + "_" + str(node) + '.pdf')
# plt.clf()


# ----------- time comparison

# df = pd.read_csv('/Users/muz1lee/Documents/华为实习/GNN/实验结果/time_compare.csv')
# print(df)
#
# fig = plt.figure(figsize=(8,6))
# x = [i for i in range(1,9)]
# y1 = df['ours_cumsum']
# y2 = df['dfs_cumsum']
# plt.plot(x,y1,marker = 's', linewidth=2.5, label = 'Ours')
# plt.plot(x,y2,marker = 'o', linewidth=2.5, label = 'Tarjans')
# plt.legend(fontsize=20)
# plt.xlabel('Adding i-th node ',fontsize=22)
# plt.ylabel('Accumulated Time(E-05)',fontsize=22)
# plt.xticks(fontsize=18)
# plt.yticks(fontsize=18)
# plt.grid()
# plt.savefig('/Users/muz1lee/Documents/华为实习/GNN/实验结果/time_compare.pdf',bbox_inches='tight')
# plt.close()
# ----------- ablation + inductive
df = pd.read_csv('/Users/muz1lee/Documents/华为实习/GNN/GFlowExplainer/compares_.csv',index_col= 0)
print(df)

df_syn1 = df[:4]
df_syn2 = df[4:8]
df_syn3 = df[8:12]
df_syn4 = df[12:16]
df_synmu = df[16:20]

f1 = plt.figure(figsize=(8,6),dpi=250)

df_new = df_syn4
columns= df_new.columns

x = [ str(item[1:])+'%' for item in columns]
y1 = df_new.iloc[0]
label1_ = df_new.index[0][:-2]
plt.plot(x,y1,marker = 's', linewidth=2.5, label = 'GFlow-Squence')


y2 = df_new.iloc[1]
label2_ = df_new.index[1][:-2]
plt.plot(x,y2,marker = 'o',linewidth=2.5, label = 'GFlowExplainer')

y3 = df_new.iloc[2]
label3_ = df_new.index[2][:-2]
plt.plot(x,y3,marker = '*', linewidth=2.5,label = 'RG-NoPretrin')

y4 = df_new.iloc[3]
label4_ = df_new.index[3][:-2]
plt.plot(x,y4, linestyle= '--', linewidth=2.5,label = 'RGExplainer')

plt.grid()
plt.ylim((0.4,1)) # 0.6,1.05

plt.legend(fontsize=18)
plt.xlabel('Ratio of Training Instances',fontsize=20)
plt.ylabel('AUC Scores',fontsize=20)
plt.title('Tree-Grid',size=22) # BA-Shapes
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.savefig('/Users/muz1lee/Documents/华为实习/GNN/实验结果/inductive_ablation/syn4.pdf',bbox_inches='tight')
# plt.show()

